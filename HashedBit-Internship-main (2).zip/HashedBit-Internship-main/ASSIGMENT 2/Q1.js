// //1. Display Even Numbers from 2 to 100


for (let i = 1; i <= 100; i++) {
  if (i % 2 === 0) {
    console.log(i);
  }
}

